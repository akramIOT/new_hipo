"""
Tests for GCP Cloud Provider.
"""
import pytest
from unittest.mock import patch, MagicMock

from src.cloud.gcp_provider import GCPProvider


@pytest.fixture
def mock_storage_client():
    """Mock GCP storage client for testing."""
    with patch("src.cloud.gcp_provider.storage") as mock:
        client_mock = MagicMock()
        mock.Client.return_value = client_mock
        yield mock


def test_gcp_provider_init():
    """Test GCPProvider initialization."""
    provider = GCPProvider(
        {
            "project_id": "test-project",
            "credentials": {
                "type": "service_account",
                "project_id": "test-project",
            },
        }
    )
    
    assert provider.project_id == "test-project"
    assert provider.provider_name == "gcp"


@patch("src.cloud.gcp_provider.storage")
def test_create_storage_bucket(mock_storage):
    """Test creating a storage bucket."""
    # Arrange
    provider = GCPProvider(
        {
            "project_id": "test-project",
            "credentials": {
                "type": "service_account",
                "project_id": "test-project",
            },
        }
    )
    
    mock_client = MagicMock()
    mock_storage.Client.return_value = mock_client
    
    # Act
    result = provider.create_storage_bucket("test-bucket")
    
    # Assert
    assert result is True
    mock_client.create_bucket.assert_called_once()


@patch("src.cloud.gcp_provider.storage")
def test_upload_file(mock_storage):
    """Test uploading a file to GCS."""
    # Arrange
    provider = GCPProvider(
        {
            "project_id": "test-project",
            "credentials": {
                "type": "service_account",
                "project_id": "test-project",
            },
        }
    )
    
    mock_client = MagicMock()
    mock_bucket = MagicMock()
    mock_blob = MagicMock()
    
    mock_storage.Client.return_value = mock_client
    mock_client.bucket.return_value = mock_bucket
    mock_bucket.blob.return_value = mock_blob
    
    # Act
    result = provider.upload_file(
        local_path="test/file.txt",
        bucket="test-bucket",
        blob_name="file.txt"
    )
    
    # Assert
    assert result is True
    mock_blob.upload_from_filename.assert_called_once()