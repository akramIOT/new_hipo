"""
Tests for AWS Cloud Provider.
"""
import pytest
from unittest.mock import patch, MagicMock

from src.cloud.aws_provider import AWSProvider


@pytest.fixture
def mock_boto3():
    """Mock boto3 for testing."""
    with patch("src.cloud.aws_provider.boto3") as mock:
        # Set up necessary mocks
        mock.client.return_value = MagicMock()
        mock.resource.return_value = MagicMock()
        yield mock


def test_aws_provider_init():
    """Test AWSProvider initialization."""
    provider = AWSProvider(
        {
            "region": "us-west-2",
            "credentials": {
                "aws_access_key_id": "test_key",
                "aws_secret_access_key": "test_secret",
            },
        }
    )
    
    assert provider.region == "us-west-2"
    assert provider.provider_name == "aws"


@patch("src.cloud.aws_provider.boto3")
def test_create_storage_bucket(mock_boto3):
    """Test creating a storage bucket."""
    # Arrange
    provider = AWSProvider(
        {
            "region": "us-west-2",
            "credentials": {
                "aws_access_key_id": "test_key",
                "aws_secret_access_key": "test_secret",
            },
        }
    )
    
    mock_s3 = MagicMock()
    mock_boto3.resource.return_value = mock_s3
    
    # Act
    result = provider.create_storage_bucket("test-bucket")
    
    # Assert
    assert result is True
    mock_s3.create_bucket.assert_called_once()


@patch("src.cloud.aws_provider.boto3")
def test_upload_file(mock_boto3):
    """Test uploading a file to S3."""
    # Arrange
    provider = AWSProvider(
        {
            "region": "us-west-2",
            "credentials": {
                "aws_access_key_id": "test_key",
                "aws_secret_access_key": "test_secret",
            },
        }
    )
    
    mock_s3 = MagicMock()
    mock_boto3.resource.return_value = mock_s3
    
    # Act
    result = provider.upload_file(
        local_path="test/file.txt",
        bucket="test-bucket",
        key="file.txt"
    )
    
    # Assert
    assert result is True
    mock_s3.Bucket.return_value.upload_file.assert_called_once()