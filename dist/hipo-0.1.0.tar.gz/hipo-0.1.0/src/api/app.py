"""
API module for ML infrastructure.
"""
import os
import logging
import json
from typing import Dict, List, Any, Optional, Union
import numpy as np
import pandas as pd
from pathlib import Path
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename

from src.models.model_base import ModelBase
from src.config.config import Config

logger = logging.getLogger(__name__)

# Initialize app
app = Flask(__name__)

# Load configuration
config = Config()

# Dictionary to hold loaded models
models = {}


def load_model(model_path: str, model_name: Optional[str] = None) -> str:
    """Load a model from disk.

    Args:
        model_path: Path to model file.
        model_name: Name to use for the model. If None, use filename.

    Returns:
        Model name.
    """
    if model_name is None:
        model_name = Path(model_path).stem

    logger.info(f"Loading model {model_name} from {model_path}")
    model = ModelBase(model_name)
    model.load(model_path)

    models[model_name] = model
    return model_name


@app.route("/api/models", methods=["GET"])
def get_models() -> Dict[str, Any]:
    """Get list of available models.

    Returns:
        JSON response with models.
    """
    model_list = []
    for name, model in models.items():
        model_info = {"name": name, "metadata": model.metadata}
        model_list.append(model_info)

    return jsonify({"status": "success", "models": model_list})


@app.route("/api/models/<model_name>", methods=["GET"])
def get_model(model_name: str) -> Dict[str, Any]:
    """Get model information.

    Args:
        model_name: Name of the model.

    Returns:
        JSON response with model information.
    """
    if model_name not in models:
        return jsonify({"status": "error", "message": f"Model {model_name} not found"}), 404

    model = models[model_name]
    model_info = {"name": model_name, "metadata": model.metadata}

    return jsonify({"status": "success", "model": model_info})


@app.route("/api/models/<model_name>/predict", methods=["POST"])
def predict(model_name: str) -> Dict[str, Any]:
    """Make predictions using a model.

    Args:
        model_name: Name of the model.

    Returns:
        JSON response with predictions.
    """
    if model_name not in models:
        return jsonify({"status": "error", "message": f"Model {model_name} not found"}), 404

    # Get data from request
    if request.json:
        # JSON data
        data = request.json.get("data")
        if data is None:
            return jsonify({"status": "error", "message": "No data provided"}), 400

        # Convert to DataFrame
        try:
            if isinstance(data, list):
                # List of records
                X = pd.DataFrame(data)
            elif isinstance(data, dict):
                # Dictionary of arrays
                X = pd.DataFrame(data)
            else:
                return jsonify({"status": "error", "message": "Invalid data format"}), 400
        except Exception as e:
            return jsonify({"status": "error", "message": f"Error parsing data: {str(e)}"}), 400
    elif request.files:
        # File upload
        file = request.files["file"]
        if not file:
            return jsonify({"status": "error", "message": "No file provided"}), 400

        # Save file
        filename = secure_filename(file.filename)
        file_path = Path(app.config["UPLOAD_FOLDER"]) / filename
        file.save(file_path)

        # Read file
        try:
            if filename.endswith(".csv"):
                X = pd.read_csv(file_path)
            elif filename.endswith(".json"):
                X = pd.read_json(file_path)
            elif filename.endswith(".parquet"):
                X = pd.read_parquet(file_path)
            else:
                return jsonify({"status": "error", "message": f"Unsupported file format: {filename}"}), 400
        except Exception as e:
            return jsonify({"status": "error", "message": f"Error reading file: {str(e)}"}), 400

        # Clean up
        os.remove(file_path)
    else:
        return jsonify({"status": "error", "message": "No data provided"}), 400

    # Make predictions
    try:
        model = models[model_name]
        predictions = model.predict(X)

        # Convert to JSON-serializable format
        if isinstance(predictions, np.ndarray):
            predictions = predictions.tolist()

        return jsonify({"status": "success", "predictions": predictions})
    except Exception as e:
        return jsonify({"status": "error", "message": f"Error making predictions: {str(e)}"}), 500


@app.route("/api/models/<model_name>/evaluate", methods=["POST"])
def evaluate(model_name: str) -> Dict[str, Any]:
    """Evaluate a model.

    Args:
        model_name: Name of the model.

    Returns:
        JSON response with evaluation metrics.
    """
    if model_name not in models:
        return jsonify({"status": "error", "message": f"Model {model_name} not found"}), 404

    # Get data from request
    if request.json:
        # JSON data
        data = request.json.get("data")
        target = request.json.get("target")

        if data is None or target is None:
            return jsonify({"status": "error", "message": "Both data and target must be provided"}), 400

        # Convert to DataFrame
        try:
            if isinstance(data, list):
                # List of records
                X = pd.DataFrame(data)
            elif isinstance(data, dict):
                # Dictionary of arrays
                X = pd.DataFrame(data)
            else:
                return jsonify({"status": "error", "message": "Invalid data format"}), 400

            # Convert target to array
            y = np.array(target)
        except Exception as e:
            return jsonify({"status": "error", "message": f"Error parsing data: {str(e)}"}), 400
    elif request.files:
        # File upload
        data_file = request.files.get("data_file")
        target_file = request.files.get("target_file")

        if not data_file or not target_file:
            return jsonify({"status": "error", "message": "Both data_file and target_file must be provided"}), 400

        # Save files
        data_filename = secure_filename(data_file.filename)
        target_filename = secure_filename(target_file.filename)

        data_path = Path(app.config["UPLOAD_FOLDER"]) / data_filename
        target_path = Path(app.config["UPLOAD_FOLDER"]) / target_filename

        data_file.save(data_path)
        target_file.save(target_path)

        # Read files
        try:
            # Read data file
            if data_filename.endswith(".csv"):
                X = pd.read_csv(data_path)
            elif data_filename.endswith(".json"):
                X = pd.read_json(data_path)
            elif data_filename.endswith(".parquet"):
                X = pd.read_parquet(data_path)
            else:
                return jsonify({"status": "error", "message": f"Unsupported data file format: {data_filename}"}), 400

            # Read target file
            if target_filename.endswith(".csv"):
                y_df = pd.read_csv(target_path)
                y = y_df.values.ravel()
            elif target_filename.endswith(".json"):
                y_df = pd.read_json(target_path)
                y = y_df.values.ravel()
            elif target_filename.endswith(".npy"):
                y = np.load(target_path)
            else:
                return (
                    jsonify({"status": "error", "message": f"Unsupported target file format: {target_filename}"}),
                    400,
                )
        except Exception as e:
            return jsonify({"status": "error", "message": f"Error reading files: {str(e)}"}), 400

        # Clean up
        os.remove(data_path)
        os.remove(target_path)
    else:
        return jsonify({"status": "error", "message": "No data provided"}), 400

    # Evaluate model
    try:
        model = models[model_name]
        metrics = model.evaluate(X, y)

        return jsonify({"status": "success", "metrics": metrics})
    except Exception as e:
        return jsonify({"status": "error", "message": f"Error evaluating model: {str(e)}"}), 500


@app.route("/health", methods=["GET"])
def health() -> Dict[str, Any]:
    """Health check endpoint.

    Returns:
        JSON response with health status.
    """
    return jsonify({"status": "success", "message": "API is running"})


def init_app(model_paths: Optional[Dict[str, str]] = None, upload_folder: Optional[str] = None) -> Flask:
    """Initialize Flask app.

    Args:
        model_paths: Dictionary mapping model names to paths.
        upload_folder: Folder to store uploaded files.

    Returns:
        Flask app.
    """
    # Configure upload folder
    if upload_folder is None:
        upload_folder = "/tmp/ml_uploads"

    os.makedirs(upload_folder, exist_ok=True)
    app.config["UPLOAD_FOLDER"] = upload_folder

    # Load models
    if model_paths:
        for name, path in model_paths.items():
            try:
                load_model(path, name)
            except Exception as e:
                logger.error(f"Error loading model {name} from {path}: {e}")

    return app


if __name__ == "__main__":
    # Initialize logging
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    # Initialize app with models from config
    model_paths = config.get("model_paths", {})
    app = init_app(model_paths)

    # Run app
    port = config.get("api_port", 5000)
    app.run(host="0.0.0.0", port=port)
