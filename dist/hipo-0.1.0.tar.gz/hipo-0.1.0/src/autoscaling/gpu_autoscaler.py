"""
GPU Autoscaler for multi-cloud Kubernetes infrastructure.
"""
import logging
import time
import threading
import json
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

from src.cloud.provider import CloudProvider

logger = logging.getLogger(__name__)


class GPUAutoscaler:
    """GPU Autoscaler for multi-cloud Kubernetes infrastructure."""

    def __init__(self, config: Dict[str, Any], cloud_providers: Dict[str, CloudProvider]):
        """Initialize GPU Autoscaler.

        Args:
            config: Autoscaling configuration.
            cloud_providers: Dictionary of cloud providers.
        """
        self.config = config
        self.cloud_providers = cloud_providers
        self.metrics_config = config.get("metrics", {})
        self.scaling_config = config.get("scaling_config", {})

        self.collection_interval = self.metrics_config.get("collection_interval", 15)  # seconds
        self.logger = logging.getLogger(f"{__name__}.GPUAutoscaler")

        # Initialize metrics thresholds
        self.gpu_metrics_thresholds = self._get_metric_thresholds("gpu_metrics")
        self.queue_metrics_thresholds = self._get_metric_thresholds("queue_metrics")
        self.response_metrics_thresholds = self._get_metric_thresholds("response_metrics")
        self.cost_metrics_thresholds = self._get_metric_thresholds("cost_metrics")

        # Scaling configuration
        self.min_replicas = self.scaling_config.get("min_replicas", 1)
        self.max_replicas = self.scaling_config.get("max_replicas", 20)
        self.target_gpu_utilization = self.scaling_config.get("target_gpu_utilization", 70)
        self.target_queue_length = self.scaling_config.get("target_queue_length", 50)
        self.scale_up_factor = self.scaling_config.get("scale_up_factor", 2)
        self.scale_down_factor = self.scaling_config.get("scale_down_factor", 0.5)
        self.stabilization_window_up = self.scaling_config.get("stabilization_window_up", 60)  # seconds
        self.stabilization_window_down = self.scaling_config.get("stabilization_window_down", 300)  # seconds
        self.enable_cost_based_scaling = self.scaling_config.get("enable_cost_based_scaling", True)
        self.max_cost_per_hour = self.scaling_config.get("max_cost_per_hour", 100)  # dollars

        # State
        self.running = False
        self.collection_thread = None
        self.last_scale_up_time = {}
        self.last_scale_down_time = {}
        self.current_metrics = {}
        self.metrics_history = {}
        self.node_group_sizes = {}

    def _get_metric_thresholds(self, metric_type: str) -> Dict[str, float]:
        """Get metric thresholds from config.

        Args:
            metric_type: Metric type.

        Returns:
            Dictionary of metric thresholds.
        """
        thresholds = {}

        for metric_config in self.metrics_config.get(metric_type, []):
            name = metric_config.get("name")
            threshold = metric_config.get("threshold")

            if name and threshold is not None:
                thresholds[name] = threshold

        return thresholds

    def start(self) -> None:
        """Start the GPU Autoscaler."""
        if self.running:
            self.logger.warning("GPU Autoscaler is already running")
            return

        self.running = True
        self.collection_thread = threading.Thread(target=self._metrics_collection_loop)
        self.collection_thread.daemon = True
        self.collection_thread.start()

        self.logger.info("GPU Autoscaler started")

    def stop(self) -> None:
        """Stop the GPU Autoscaler."""
        self.running = False

        if self.collection_thread:
            self.collection_thread.join(timeout=5.0)
            self.collection_thread = None

        self.logger.info("GPU Autoscaler stopped")

    def _metrics_collection_loop(self) -> None:
        """Metrics collection loop."""
        while self.running:
            try:
                self._collect_metrics()
                self._evaluate_scaling()
            except Exception as e:
                self.logger.error(f"Error in metrics collection loop: {e}")

            time.sleep(self.collection_interval)

    def _collect_metrics(self) -> None:
        """Collect metrics from all cloud providers."""
        timestamp = datetime.now().isoformat()

        # Collect metrics from each cloud provider
        for provider_name, provider in self.cloud_providers.items():
            if not provider.is_enabled():
                continue

            try:
                # Get GPU metrics
                gpu_metrics = provider.get_gpu_metrics()

                # In a real implementation, this would also collect queue metrics
                # and response metrics from the LLM service
                queue_metrics = self._simulate_queue_metrics()
                response_metrics = self._simulate_response_metrics()

                # Get cost metrics
                cost_metrics = provider.get_cost_metrics(timeframe="hourly")

                # Get current node group sizes
                node_groups = provider.get_node_groups()
                self.node_group_sizes[provider_name] = {
                    node_group.get("name"): node_group.get("desiredCapacity", 0) for node_group in node_groups
                }

                # Store metrics
                self.current_metrics[provider_name] = {
                    "timestamp": timestamp,
                    "gpu_metrics": gpu_metrics,
                    "queue_metrics": queue_metrics,
                    "response_metrics": response_metrics,
                    "cost_metrics": cost_metrics,
                }

                # Add to history
                if provider_name not in self.metrics_history:
                    self.metrics_history[provider_name] = []

                self.metrics_history[provider_name].append(self.current_metrics[provider_name])

                # Trim history to keep only recent data
                max_history_entries = 100
                if len(self.metrics_history[provider_name]) > max_history_entries:
                    self.metrics_history[provider_name] = self.metrics_history[provider_name][-max_history_entries:]

                self.logger.debug(f"Collected metrics for {provider_name}")
            except Exception as e:
                self.logger.error(f"Error collecting metrics for {provider_name}: {e}")

    def _simulate_queue_metrics(self) -> Dict[str, Any]:
        """Simulate queue metrics for demonstration.

        Returns:
            Dictionary of queue metrics.
        """
        # In a real implementation, this would collect metrics from the LLM service queue
        return {"queue_length": 75, "queue_latency": 1500}  # ms

    def _simulate_response_metrics(self) -> Dict[str, Any]:
        """Simulate response metrics for demonstration.

        Returns:
            Dictionary of response metrics.
        """
        # In a real implementation, this would collect metrics from the LLM service
        return {
            "latency_p50": 500,  # ms
            "latency_p95": 800,  # ms
            "latency_p99": 1200,  # ms
            "error_rate": 2.5,  # percentage
        }

    def _evaluate_scaling(self) -> None:
        """Evaluate if scaling is needed based on collected metrics."""
        for provider_name, metrics in self.current_metrics.items():
            if provider_name not in self.cloud_providers:
                continue

            provider = self.cloud_providers[provider_name]
            if not provider.is_enabled():
                continue

            try:
                # Check if we're in stabilization window
                now = datetime.now()

                last_scale_up = self.last_scale_up_time.get(provider_name)
                if last_scale_up and (now - last_scale_up).total_seconds() < self.stabilization_window_up:
                    self.logger.info(
                        f"In scale-up stabilization window for {provider_name}, skipping scaling evaluation"
                    )
                    continue

                last_scale_down = self.last_scale_down_time.get(provider_name)
                if last_scale_down and (now - last_scale_down).total_seconds() < self.stabilization_window_down:
                    self.logger.info(
                        f"In scale-down stabilization window for {provider_name}, skipping scaling evaluation"
                    )
                    continue

                # Get node groups for this provider
                node_groups = provider.get_node_groups()

                for node_group in node_groups:
                    node_group_name = node_group.get("name")

                    # Skip if not a GPU node group
                    if not self._is_gpu_node_group(node_group):
                        continue

                    # Get current size
                    current_size = self._get_node_group_size(node_group)

                    # Calculate desired size based on metrics
                    desired_size = self._calculate_desired_size(provider_name, node_group_name, current_size)

                    # Apply min/max constraints
                    desired_size = max(self.min_replicas, min(desired_size, self.max_replicas))

                    # If no change, continue
                    if desired_size == current_size:
                        self.logger.info(f"No scaling needed for {provider_name}/{node_group_name}")
                        continue

                    # Check cost constraints if scaling up
                    if desired_size > current_size and self.enable_cost_based_scaling:
                        cost_metrics = metrics.get("cost_metrics", {})
                        current_cost = cost_metrics.get("cost_per_hour", 0.0)
                        estimated_cost = current_cost * (desired_size / current_size)

                        if estimated_cost > self.max_cost_per_hour:
                            self.logger.warning(
                                f"Cost constraint violated for {provider_name}/{node_group_name}: "
                                f"estimated cost ${estimated_cost:.2f} > ${self.max_cost_per_hour:.2f}"
                            )
                            # Scale to maximum affordable size
                            affordable_size = int(current_size * (self.max_cost_per_hour / current_cost))
                            desired_size = max(current_size, affordable_size)

                    # Apply scaling
                    self.logger.info(f"Scaling {provider_name}/{node_group_name} from {current_size} to {desired_size}")
                    if provider.scale_node_group(node_group_name, desired_size):
                        if desired_size > current_size:
                            self.last_scale_up_time[provider_name] = now
                        else:
                            self.last_scale_down_time[provider_name] = now

                        self.logger.info(f"Successfully scaled {provider_name}/{node_group_name} to {desired_size}")
                    else:
                        self.logger.error(f"Failed to scale {provider_name}/{node_group_name}")
            except Exception as e:
                self.logger.error(f"Error evaluating scaling for {provider_name}: {e}")

    def _is_gpu_node_group(self, node_group: Dict[str, Any]) -> bool:
        """Check if a node group is a GPU node group.

        Args:
            node_group: Node group configuration.

        Returns:
            True if the node group is a GPU node group, False otherwise.
        """
        # Check for GPU instance types (simplified for demonstration)
        instance_type = node_group.get("instance_type", "")
        if any(gpu_type in instance_type.lower() for gpu_type in ["gpu", "g4", "g5", "p2", "p3", "p4"]):
            return True

        # Check for GPU in labels
        labels = node_group.get("labels", {})
        if labels.get("node-type") == "gpu":
            return True

        # Check for GPU accelerators (GCP)
        accelerators = node_group.get("accelerators", [])
        if accelerators:
            return True

        return False

    def _get_node_group_size(self, node_group: Dict[str, Any]) -> int:
        """Get the current size of a node group.

        Args:
            node_group: Node group configuration.

        Returns:
            Current size of the node group.
        """
        # AWS-style
        if "desiredCapacity" in node_group:
            return node_group["desiredCapacity"]
        # GCP-style
        elif "autoscaling" in node_group:
            return node_group["initialNodeCount"]
        # Default
        else:
            return 0

    def _calculate_desired_size(self, provider_name: str, node_group_name: str, current_size: int) -> int:
        """Calculate the desired size of a node group based on metrics.

        Args:
            provider_name: Cloud provider name.
            node_group_name: Node group name.
            current_size: Current size of the node group.

        Returns:
            Desired size of the node group.
        """
        metrics = self.current_metrics.get(provider_name, {})
        gpu_metrics = metrics.get("gpu_metrics", {})
        queue_metrics = metrics.get("queue_metrics", {})
        response_metrics = metrics.get("response_metrics", {})

        # Calculate scaling based on GPU utilization
        avg_gpu_utilization = self._get_average_metric(gpu_metrics, "gpu_utilization")
        if avg_gpu_utilization > self.gpu_metrics_thresholds.get("duty_cycle", 80):
            # Scale up based on GPU utilization
            utilization_ratio = avg_gpu_utilization / self.target_gpu_utilization
            gpu_based_size = int(current_size * utilization_ratio)
        elif avg_gpu_utilization < 0.7 * self.target_gpu_utilization:
            # Scale down based on GPU utilization
            utilization_ratio = avg_gpu_utilization / self.target_gpu_utilization
            gpu_based_size = max(1, int(current_size * utilization_ratio))
        else:
            # Utilization is within target range
            gpu_based_size = current_size

        # Calculate scaling based on queue length
        queue_length = queue_metrics.get("queue_length", 0)
        if queue_length > self.queue_metrics_thresholds.get("queue_length", 100):
            # Scale up based on queue length
            queue_ratio = queue_length / self.target_queue_length
            queue_based_size = int(current_size * min(queue_ratio, self.scale_up_factor))
        elif queue_length < 0.3 * self.target_queue_length:
            # Scale down based on queue length
            queue_based_size = max(1, int(current_size * self.scale_down_factor))
        else:
            # Queue length is within target range
            queue_based_size = current_size

        # Calculate scaling based on response latency
        latency_p95 = response_metrics.get("latency_p95", 0)
        latency_threshold = self.response_metrics_thresholds.get("latency_p95", 1000)
        if latency_p95 > latency_threshold:
            # Scale up based on latency
            latency_ratio = latency_p95 / latency_threshold
            latency_based_size = int(current_size * min(latency_ratio, self.scale_up_factor))
        else:
            # Latency is within target range
            latency_based_size = current_size

        # Take the maximum of all calculated sizes
        desired_size = max(gpu_based_size, queue_based_size, latency_based_size)

        self.logger.debug(
            f"Scaling calculation for {provider_name}/{node_group_name}: "
            f"current={current_size}, gpu={gpu_based_size}, queue={queue_based_size}, "
            f"latency={latency_based_size}, desired={desired_size}"
        )

        return desired_size

    def _get_average_metric(self, metrics: Dict[str, Dict[str, float]], metric_name: str) -> float:
        """Get the average value of a metric across all nodes.

        Args:
            metrics: Dictionary of metrics.
            metric_name: Metric name.

        Returns:
            Average value of the metric.
        """
        if not metrics or metric_name not in metrics:
            return 0.0

        values = metrics[metric_name].values()
        if not values:
            return 0.0

        return sum(values) / len(values)

    def get_current_metrics(self) -> Dict[str, Any]:
        """Get current metrics.

        Returns:
            Dictionary of current metrics.
        """
        return self.current_metrics

    def get_scaling_history(self) -> Dict[str, Any]:
        """Get scaling history.

        Returns:
            Dictionary of scaling history.
        """
        history = {}

        for provider_name, metrics_list in self.metrics_history.items():
            if provider_name not in history:
                history[provider_name] = []

            for metrics in metrics_list:
                history[provider_name].append(
                    {
                        "timestamp": metrics["timestamp"],
                        "gpu_utilization": self._get_average_metric(metrics["gpu_metrics"], "gpu_utilization"),
                        "queue_length": metrics["queue_metrics"].get("queue_length", 0),
                        "latency_p95": metrics["response_metrics"].get("latency_p95", 0),
                        "node_group_sizes": self.node_group_sizes.get(provider_name, {}),
                    }
                )

        return history
