"""HIPO - Multi-Cloud Kubernetes ML Platform.

A modular and scalable infrastructure for deploying machine learning and LLM models across multiple cloud providers.
"""

__version__ = "0.1.0"
