"""
API gateway module for multi-cloud Kubernetes infrastructure.
"""
