"""
Cloud provider module for multi-cloud Kubernetes infrastructure.
"""
