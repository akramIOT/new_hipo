# HIPO Documentation

Welcome to the documentation for HIPO - the Multi-Cloud Kubernetes ML Platform.

## Overview

HIPO is a comprehensive platform for deploying machine learning and large language models (LLMs) across multiple cloud providers using Kubernetes. It provides a unified interface for model training, deployment, and serving with built-in security, observability, and cost optimization features.

## Table of Contents

- [Getting Started](./getting-started.md)
- [Architecture](./architecture.md)
- [Security Guide](./security-guide.md)
- [API Reference](./api-reference.md)
- [UI Documentation](./ui-documentation.md)
- [Tutorials](./tutorials/README.md)
- [Contributing](./contributing.md)